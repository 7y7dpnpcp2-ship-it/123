import torch

# 加载 .pt 文件
file_path = "gen_batch_step_1.pt"  # 替换为你的文件路径
data = torch.load(file_path)

# 打印数据格式
print("Data Type:", type(data))
print("Data Shape:", data.shape if isinstance(data, torch.Tensor) else "Not a Tensor")
print("Sample Data:\n", data[:2])  # 显示前两行示例