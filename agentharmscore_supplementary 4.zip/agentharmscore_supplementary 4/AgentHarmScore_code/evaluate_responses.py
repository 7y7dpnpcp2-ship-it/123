import json
import argparse
import numpy as np
from tqdm import tqdm

# 只导入 harmful 的评分函数
from benchmark.harmful_grading_functions import *

def evaluate_responses(args):
    print("Starting evaluation...", flush=True)
    
    # 加载生成的响应
    print(f"Loading responses from {args.responses_file}", flush=True)
    with open(args.responses_file, 'r') as f:
        responses = json.load(f)
    print(f"Loaded {len(responses)} responses", flush=True)
    
    results = []
    category_scores = {}
    
    for response in tqdm(responses, desc="Evaluating", ncols=100, mininterval=1.0):
        messages = [
            {"role": "user", "content": response['input']},
            {"role": "assistant", "content": response['output']}
        ]
        
        metadata = {
            "id": response['id'],
            "category": response['category'],
            "grading_function": response['grading_function'],
            "target_functions": response['target_functions']
        }
        
        print(f"Processing sample {response['id']}", flush=True)
        grading_function_name = metadata["grading_function"]
        score_dict = globals()[grading_function_name](metadata, messages)
        score = np.mean(list(score_dict.values()))
        
        # 添加到结果
        result = {
            'id': response['id'],
            'category': response['category'],
            'score': score,
            'score_breakdown': score_dict
        }
        results.append(result)
        
        # 更新类别统计
        category = response['category']
        if category not in category_scores:
            category_scores[category] = []
        category_scores[category].append(score)
        
        print(f"Completed sample {response['id']} with score {score:.1%}", flush=True)
    
    print("\nCalculating final scores...", flush=True)
    # 计算并打印结果
    avg_score = np.mean([r['score'] for r in results])
    category_avg_scores = {cat: np.mean(scores) for cat, scores in category_scores.items()}
    
    print(f'Average score: {avg_score:.1%}')
    print(f"Category-wise average scores: " + ', '.join([f"{category} {avg_score:.1%}" for category, avg_score in category_avg_scores.items()]))
    
    # 保存详细结果
    print("\nSaving results...", flush=True)
    output_file = "evaluation_results.json"
    with open(output_file, 'w') as f:
        json.dump({
            'results': results,
            'avg_score': avg_score,
            'category_scores': category_avg_scores
        }, f, indent=2)
    print(f"Results saved to {output_file}", flush=True)
    print("Evaluation completed!", flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--responses_file', type=str, required=True)
    args = parser.parse_args()
    
    evaluate_responses(args)