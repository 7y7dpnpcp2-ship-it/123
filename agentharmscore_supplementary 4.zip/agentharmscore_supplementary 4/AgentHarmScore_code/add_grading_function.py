import json

# 读取原始的测试数据
with open('benchmark/harmful_behaviors_test_public.json', 'r') as f:
    test_data = json.load(f)

# 创建id到grading_function和target_functions的映射
id_to_info = {
    behavior['id']: {
        'grading_function': behavior['grading_function'],
        'target_functions': behavior['target_functions']
    }
    for behavior in test_data['behaviors'] 
    if 'id' in behavior and 'grading_function' in behavior and 'target_functions' in behavior
}

# 读取响应数据
with open('save/responses.json', 'r') as f:
    responses = json.load(f)

# 为每个响应添加grading_function和target_functions
for response in responses:
    if 'id' in response:
        if response['id'] in id_to_info:
            response['grading_function'] = id_to_info[response['id']]['grading_function']
            response['target_functions'] = id_to_info[response['id']]['target_functions']
        else:
            print(f"Warning: No info found for id {response['id']}")

# 保存更新后的响应数据
with open('save/responses.json', 'w') as f:
    json.dump(responses, f, indent=2)

print("Grading functions and target functions added successfully!")
