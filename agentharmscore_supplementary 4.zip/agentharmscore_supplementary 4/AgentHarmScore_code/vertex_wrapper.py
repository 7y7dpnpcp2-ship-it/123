from inspect_ai.model import get_model, GenerateConfig, Model, Content
from typing import List, Dict, Any, Optional

class VertexWrapper:
    def __init__(self, model_name: str, config: GenerateConfig, safety_settings: Dict[str, str]):
        self.model = get_model(
            model_name,
            config=config,
            safety_settings=safety_settings
        )
    
    async def convert_messages(self, messages: List[Any]) -> List[Dict[str, str]]:
        converted_messages = []
        for message in messages:
            if isinstance(message, Content):
                role = getattr(message, 'role', 'user')
                content = getattr(message, 'content', str(message))
            else:
                role = message.get('role', 'user')
                content = message.get('content', str(message))
            
            converted_messages.append({
                'role': role,
                'content': content
            })
        return converted_messages

    async def generate(self, input_messages: List[Any], **kwargs) -> Any:
        converted_messages = await self.convert_messages(input_messages)
        return await self.model.generate(input=converted_messages, **kwargs) 