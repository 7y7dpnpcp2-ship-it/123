# LLaDA-based Paraphrasing, Response Generation, and Evaluation Pipeline

This document outlines the steps to run the paraphrasing, response generation, and evaluation pipeline using LLaDA and related scripts, as referenced in the appendix.


## 1. Environment Setup
First, set up the required environment by following the instructions in the LLaDA repository:  
[https://github.com/ML-GSAI/LLaDA/tree/main](https://github.com/ML-GSAI/LLaDA/tree/main)  

After setup, ensure you have the `LLaDA-8B-Instruct` model downloaded and saved locally (you will need to prepare this model yourself as per the repository guidelines).


## 2. Generate Paraphrases with LLaDA
Use LLaDA to paraphrase the input dataset. This paraphrased output will serve as input for subsequent response generation.

### Basic Command:
```bash
python generate_paraphrasing_total.py \
  --input /path/to/your/agentharm_prompts.jsonl \
  --output ./output_paraphrases.jsonl \
  --num_samples 3 \
  --base_seed 42
```

### For Background Execution (with more samples):
```bash
CUDA_VISIBLE_DEVICES=<your_gpu_id> nohup \
python generate_paraphrasing_total.py \
  --input /path/to/your/agentharm_prompts.jsonl \
  --output ./output_paraphrases.jsonl \
  --num_samples 10 \
  --base_seed 42 \
> generate_paraphrasing.log 2>&1 &
```

### Notes:
- Adjust hyperparameters (e.g., `temperature`, `gen_len`) and refine the prompt template to ensure generated paraphrases are natural and consistent.
- Replace `<your_gpu_id>` with the ID of your target GPU (e.g., `3`).


## 3. Generate Responses Using Paraphrased Data
Use the paraphrased output (from Step 2) as input to generate model responses. Here we use `Llama-3.1-8B-Instruct` as an example:

```bash
CUDA_VISIBLE_DEVICES=<your_gpu_id> nohup \
python generate_responses.py \
  --dataset_path /path/to/your/custom_dataset.json \  # Use paraphrased data here
  --model_name "hf//path/to/your/Llama-3.1-8B-Instruct" \  # Path to your local model
  --prompt_template_name empty \
  --output_path /path/to/your/save/responses_custom.json \
> generate_responses_custom.log 2>&1 &
```

### Notes:
- Replace `/path/to/your/custom_dataset.json` with the path to your paraphrased dataset.
- Update `--model_name` to point to your local model checkpoint.


## 4. Evaluate Generated Responses
Run the evaluation script on the generated responses:

```bash
CUDA_VISIBLE_DEVICES=<gpu_ids> nohup \
python evaluate_responses.py \
  --responses_file /path/to/your/save/responses_Llama-3.1-8B-Instruct.json \
> evaluate_Llama-3.1-8B-Instruct.log 2>&1 &
```

### Notes:
- Replace `<gpu_ids>` with the IDs of GPUs to use (e.g., `0,1,2,3` for multi-GPU evaluation).
- Ensure `--responses_file` points to the output from Step 3.


## 5. Checking Grading Functions
After successful evaluation, verify the grading logic in the following file:  
`/path/to/your/AgentHarm/benchmark/harmful_grading_functions.py`  

### Key Checks:
1. **LLM Configuration (Lines 50-60)**: The file defines the LLM used for evaluation, currently set to `float16`. This may impact results—consider testing with full-precision (e.g., `float32`) for comparison.  
2. **Function Integrity**: The grading functions are partially modified by LLMs. If errors occur during evaluation, inspect these functions for issues (e.g., syntax, logical inconsistencies) and debug as needed.  


Contact the authors for additional clarification on any step.