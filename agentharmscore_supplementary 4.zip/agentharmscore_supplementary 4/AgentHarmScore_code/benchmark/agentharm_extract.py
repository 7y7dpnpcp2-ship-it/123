import json
import random
import os

def create_directory(base_path, input_file_name):
    base_name = os.path.splitext(os.path.basename(input_file_name))[0]
    new_dir = os.path.join(base_path, base_name)
    os.makedirs(new_dir, exist_ok=True)
    return new_dir

def load_json_file(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def save_to_jsonl(data, output_file):
    with open(output_file, 'w') as file:
        for item in data:
            json.dump(item, file)
            file.write('\n')

def process_dataset(input_file, output_dir, sample_size=None):
    data = load_json_file(input_file)
    behaviors = data['behaviors']
    
    processed_data = []
    for behavior in behaviors:
        prompt = behavior['prompt']
        other_info = {k: v for k, v in behavior.items() if k != 'prompt'}
        
        processed_item = {
            "prompt": prompt,
            "other_info": other_info
        }
        processed_data.append(processed_item)
    
    # 如果指定了sample_size，随机采样
    if sample_size:
        processed_data = random.sample(processed_data, min(sample_size, len(processed_data)))
    
    output_file_prompts = os.path.join(output_dir, 'agentharm_prompts.jsonl')
    output_file_full = os.path.join(output_dir, 'agentharm_full_data.jsonl')
    
    # 保存只包含 prompt 的文件
    save_to_jsonl([{"src": item["prompt"], "trg": item["prompt"]} for item in processed_data], output_file_prompts)
    
    # 保存包含其余信息的文件
    save_to_jsonl(processed_data, output_file_full)
    
    print(f"Total behaviors processed: {len(processed_data)}")
    print(f"Processed prompts have been written to {output_file_prompts}")
    print(f"Processed full data has been written to {output_file_full}")

# 使用示例
input_file = '/research/d1/gds//AgentHarm/benchmark/harmful_behaviors_llm_only.json'
current_dir = os.getcwd()  # 获取当前目录
output_dir = current_dir   # 直接使用当前目录

# 如果不需要采样，可以不传入sample_size参数
process_dataset(input_file, output_dir)