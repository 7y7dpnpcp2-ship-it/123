import json
import os

def combine_paraphrase_with_full_data(paraphrase_file, full_data_file, output_file):
    """
    将改写结果与原始完整数据组合成自定义数据集格式
    """
    # 读取改写结果
    paraphrases = {}
    with open(paraphrase_file, 'r') as f:
        for line in f:
            if line.strip():
                data = json.loads(line)
                text_idx = data['text_index']
                attempt = data['attempt']
                if text_idx not in paraphrases:
                    paraphrases[text_idx] = []
                paraphrases[text_idx].append({
                    'paraphrased_text': data['paraphrased_text'],
                    'attempt': attempt,
                    'seed': data['seed']
                })

    # 读取完整数据
    with open(full_data_file, 'r') as f:
        full_data = []
        for line in f:
            if line.strip():
                full_data.append(json.loads(line))

    # 组合数据
    combined_data = {
        "behaviors": []
    }
    
    for idx, original_data in enumerate(full_data):
        if idx in paraphrases:
            original_info = original_data.get('other_info', {})
            
            # 为每个改写版本创建一个新条目
            for paraphrase in paraphrases[idx]:
                behavior = {
                    "id": f"{original_info.get('id', 'unknown')}_{paraphrase['attempt']}",
                    "id_original": original_info.get('id', 'unknown'),
                    "detailed_prompt": original_info.get('detailed_prompt', ''),
                    "hint_included": 'Hint:' in original_data['prompt'],
                    "name": original_info.get('name', ''),
                    "category": original_info.get('category', 'unknown'),
                    "prompt": paraphrase['paraphrased_text'],
                    "target_functions": original_info.get('target_functions', []),
                    "grading_function": original_info.get('grading_function', ''),
                    "seed": paraphrase['seed'],
                    "attempt": paraphrase['attempt'],
                    "original_prompt": original_data['prompt']
                }
                combined_data["behaviors"].append(behavior)

    # 保存组合后的数据
    with open(output_file, 'w') as f:
        json.dump(combined_data, f, indent=2)

# 使用示例
paraphrase_file = "/research/d1/gds//ParaGuide/results/paraphrase_results/2024-11-22_15-02-01/style.jsonl"
full_data_file = "agentharm_full_data.jsonl"
output_file = "custom_dataset.json"

combine_paraphrase_with_full_data(paraphrase_file, full_data_file, output_file)
