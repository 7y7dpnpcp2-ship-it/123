import json
import re
from collections import defaultdict

def extract_llm_grading_prompts():
    # 读取包含 prompts 的 JSON 文件
    with open('/research/d1/gds//AgentHarm/benchmark/harmful_behaviors_test_public.json', 'r') as f:
        data = json.load(f)
    
    # 先统计原始文件中的所有category
    original_categories = set()
    for behavior in data['behaviors']:
        original_categories.add(behavior['category'])
    
    print("\n=== Original File Categories ===")
    print(f"Total categories in original file: {len(original_categories)}")
    print("\nCategories:")
    for i, category in enumerate(sorted(original_categories), 1):
        print(f"{i}. {category}")
    
    # 读取 grading functions 文件内容
    with open('/research/d1/gds//AgentHarm/benchmark/harmful_grading_functions.py', 'r') as f:
        grading_content = f.read()
    
    llm_grading_info = {}
    total_behaviors = len(data['behaviors'])
    llm_prompt_count = 0
    
    # 创建新的JSON数据结构
    filtered_data = {
        "behaviors": []
    }
    
    # 添加category统计
    category_total = defaultdict(int)
    category_llm = defaultdict(int)
    all_categories = set()  # 用于统计所有category的数量
    
    # 遍历所有行为
    for behavior in data['behaviors']:
        grading_func_name = behavior['grading_function']
        category = behavior['category']
        category_total[category] += 1
        all_categories.add(category)  # 添加到集合中
        
        pattern = f"def {grading_func_name}.*?def"
        matches = re.findall(pattern, grading_content, re.DOTALL)
        
        if matches:
            func_content = matches[0]
            if 'llm_prompt' in func_content or 'semantic_judge' in func_content:
                prompt_pattern = r'llm_prompt\s*=\s*[\"\"\"|\'\'\']([^\"\"\"\'\'\']+)[\"\"\"|\'\'\']'
                prompt_matches = re.findall(prompt_pattern, func_content)
                llm_prompt_count += 1
                category_llm[category] += 1
                
                # 将匹配的behavior添加到新的JSON数据中
                filtered_data["behaviors"].append(behavior)
                
                llm_grading_info[behavior['name']] = {
                    'id': behavior['id'],
                    'category': category,
                    'grading_function': grading_func_name,
                    'llm_prompts': prompt_matches if prompt_matches else []
                }
    
    # 保存筛选后的数据到新的JSON文件
    with open('/research/d1/gds//AgentHarm/benchmark/harmful_behaviors_llm_only.json', 'w') as f:
        json.dump(filtered_data, f, indent=4)
    
    return llm_grading_info, total_behaviors, llm_prompt_count, category_total, category_llm, all_categories

# 运行函数并打印结果
llm_gradings, total_behaviors, llm_prompt_count, category_total, category_llm, all_categories = extract_llm_grading_prompts()

# 打印总体统计
print(f"\nTotal behaviors: {total_behaviors}")
print(f"Behaviors with LLM prompts: {llm_prompt_count}")
print(f"Percentage: {(llm_prompt_count/total_behaviors)*100:.2f}%")
print(f"Total number of categories: {len(all_categories)}\n")

# 打印所有category名称
print("=== All Categories ===")
for i, category in enumerate(sorted(all_categories), 1):
    print(f"{i}. {category}")

# 打印每个category的统计
print("\n=== Category Statistics ===")
for category in sorted(category_total.keys()):
    total = category_total[category]
    llm_count = category_llm[category]
    percentage = (llm_count/total)*100 if total > 0 else 0
    print(f"\nCategory: {category}")
    print(f"Total behaviors: {total}")
    print(f"Behaviors with LLM prompts: {llm_count}")
    print(f"Percentage: {percentage:.2f}%")

# 打印详细信息
print("\n=== Detailed Information ===")
for name, info in llm_gradings.items():
    print(f"\n=== {name} ===")
    print(f"ID: {info['id']}")
    print(f"Category: {info['category']}")
    print(f"Grading Function: {info['grading_function']}")
    print("LLM Prompts:")
    for i, prompt in enumerate(info['llm_prompts'], 1):
        print(f"{i}. {prompt.strip()}")

print("\nFiltered data has been saved to 'harmful_behaviors_llm_only.json'")