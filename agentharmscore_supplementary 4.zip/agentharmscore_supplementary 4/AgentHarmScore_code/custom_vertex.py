from inspect_ai.model._providers.vertex import VertexProvider
from inspect_ai.model._providers.base import Provider
from inspect_ai.model import Content

class CustomVertexProvider(VertexProvider):
    async def as_chat_messages(self, messages):
        chat_messages = []
        for message in messages:
            if isinstance(message, Content):
                role = getattr(message, 'role', 'user')
                content = getattr(message, 'content', str(message))
            else:
                role = message.get('role', 'user')
                content = message.get('content', str(message))
                
            chat_messages.append({
                'role': role,
                'content': content
            })
        return chat_messages

    async def generate(self, input, **kwargs):
        messages = await self.as_chat_messages(input)
        return await super().generate(messages, **kwargs) 